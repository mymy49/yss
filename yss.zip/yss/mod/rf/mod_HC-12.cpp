////////////////////////////////////////////////////////////////////////////////////////
//
// 저작권 표기 License_ver_3.0
// 본 소스 코드의 소유권은 홍윤기에게 있습니다.
// 어떠한 형태든 기여는 기증으로 받아들입니다.
// 본 소스 코드는 아래 사항에 동의할 경우에 사용 가능합니다.
// 아래 사항에 대해 동의하지 않거나 이해하지 못했을 경우 사용을 금합니다.
// 본 소스 코드를 사용하였다면 아래 사항을 모두 동의하는 것으로 자동 간주 합니다.
// 본 소스 코드의 상업적 또는 비 상업적 이용이 가능합니다.
// 본 소스 코드의 내용을 임의로 수정하여 재배포하는 행위를 금합니다.
// 본 소스 코드의 내용을 무단 전재하는 행위를 금합니다.
// 본 소스 코드의 사용으로 인해 발생하는 모든 사고에 대해서 어떠한 법적 책임을 지지 않습니다.
//
// Home Page : http://cafe.naver.com/yssoperatingsystem
// Copyright 2022. 홍윤기 all right reserved.
//
////////////////////////////////////////////////////////////////////////////////////////

//#include <__cross_studio_io.h>
#include <mod/rf/HC-12.h>
#include <util/ElapsedTime.h>
#include <yss/thread.h>

#ifndef YSS_DRV_UART_UNSUPPORTED

namespace mod
{
namespace rf
{
HC_12::HC_12(void)
{
	mPeri = 0;
}

bool HC_12::init(Config config)
{
	mPeri = &config.peri;
	mSet = config.set;
	mSet.port->setOutput(mSet.pin, true);

	return true;
}

bool HC_12::send(void *src, unsigned int size)
{
	return mPeri->send(src, size);
}

char HC_12::getWaitUntilReceive(void)
{
	return mPeri->getWaitUntilReceive();
}

signed short HC_12::get(void)
{
	return mPeri->get();
}

bool HC_12::checkOk(char *src, unsigned char len)
{
	ElapsedTime timeout;
	signed short data;
	unsigned char index = 0;

	while (1)
	{
		data = mPeri->get();
		if (data >= 0)
		{
			if (src[index] == (char)data)
				index++;
			else
			{
				mSet.port->setOutput(mSet.pin, true);
				return false;
			}

			if (index == len)
			{
				mSet.port->setOutput(mSet.pin, true);
				return true;
			}
		}

		if (timeout.getMsec() >= 500)
		{
			mSet.port->setOutput(mSet.pin, true);
			return false;
		}
	}
}

bool HC_12::setBaudrate(unsigned char baud)
{
	char str[16] = {
		'A',
		'T',
		'+',
		'B',
	};
	unsigned char index = 4;

	mSet.port->setOutput(mSet.pin, false);
	thread::delay(100);
	mPeri->flush();

	switch (baud)
	{
	case BAUD_1200:
		str[index++] = '1';
		str[index++] = '2';
		break;
	case BAUD_2400:
		str[index++] = '2';
		str[index++] = '4';
		break;
	case BAUD_4800:
		str[index++] = '4';
		str[index++] = '8';
		break;
	case BAUD_9600:
		str[index++] = '9';
		str[index++] = '6';
		break;
	case BAUD_19200:
		str[index++] = '1';
		str[index++] = '9';
		str[index++] = '2';
		break;
	case BAUD_38400:
		str[index++] = '3';
		str[index++] = '8';
		str[index++] = '4';
		break;
	case BAUD_57600:
		str[index++] = '5';
		str[index++] = '7';
		str[index++] = '6';
		break;
	case BAUD_115200:
		str[index++] = '1';
		str[index++] = '1';
		str[index++] = '5';
		str[index++] = '2';
		break;
	}

	str[index++] = '0';
	str[index++] = '0';
	str[index++] = 0x0D;
	str[index++] = 0x0A;

	mPeri->send(str, index);

	str[0] = 'O';
	str[1] = 'K';

	return checkOk(str, index);
}

bool HC_12::setChannel(unsigned char channel)
{
	if (channel < 1 || channel > 127)
		return false;

	char str[16] = {
		'A',
		'T',
		'+',
		'C',
	};
	unsigned char index = 4, buf;

	mSet.port->setOutput(mSet.pin, false);
	thread::delay(100);
	mPeri->flush();

	buf = channel / 100;
	str[index++] = '0' + buf;

	buf = channel % 100 / 10;
	str[index++] = '0' + buf;

	buf = channel % 10;
	str[index++] = '0' + buf;

	str[index++] = 0x0D;
	str[index++] = 0x0A;

	mPeri->send(str, index);

	str[0] = 'O';
	str[1] = 'K';

	return checkOk(str, index);
}

bool HC_12::setFU(unsigned char fu)
{
	if (fu < 1 || fu > 4)
		return false;

	char str[16] = {
		'A',
		'T',
		'+',
		'F',
		'U',
	};
	unsigned char index = 5, buf;

	mSet.port->setOutput(mSet.pin, false);
	thread::delay(100);
	mPeri->flush();

	str[index++] = '0' + fu;

	str[index++] = 0x0D;
	str[index++] = 0x0A;

	mPeri->send(str, index);

	str[0] = 'O';
	str[1] = 'K';

	return checkOk(str, index);
}

bool HC_12::setTransmittingPower(unsigned char power)
{
	if (power < 1 || power > 8)
		return false;

	char str[16] = {
		'A',
		'T',
		'+',
		'P',
	};
	unsigned char index = 4, buf;

	mSet.port->setOutput(mSet.pin, false);
	thread::delay(100);
	mPeri->flush();

	str[index++] = '0' + power;

	str[index++] = 0x0D;
	str[index++] = 0x0A;

	mPeri->send(str, index);

	str[0] = 'O';
	str[1] = 'K';

	return checkOk(str, index);
}
}
}

#endif

